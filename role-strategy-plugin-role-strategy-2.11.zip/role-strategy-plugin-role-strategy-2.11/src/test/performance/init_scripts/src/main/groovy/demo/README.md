Demo jobs
===

This directory contains a set of demo `Jenkinsfile`s.
System Groovy scripts process this directory and create jobs for each job.
