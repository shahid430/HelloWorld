buildPlugin(platforms: ['linux'],
    repo: 'https://github.com/jenkinsci/job-restrictions-plugin.git',
    findbugs: [archive: true, unstableTotalAll: '0'])
